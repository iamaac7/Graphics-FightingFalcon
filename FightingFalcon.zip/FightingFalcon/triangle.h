void triangle()
{

        glBegin(GL_TRIANGLES);
       // glColor3f(0, 1, 0);
        glColor3ub(153, 115, 0);
		//glColor3ub(102, 224, 255);
        glVertex2f(-1200, 300);
        glVertex2f(-1000, 300);
        glVertex2f(-1100, 400);
        glEnd();

        glBegin(GL_TRIANGLES);
        //glColor3f(0, 1, 0);
        glVertex2f(-1000, 300);
        glVertex2f(-800, 300);
        glVertex2f(-900, 400);
        glEnd();

        glBegin(GL_TRIANGLES);
        //glColor3f(0, 1, 0);
        glVertex2f(-800, 300);
        glVertex2f(-600, 300);
        glVertex2f(-700, 400);
        glEnd();

        glBegin(GL_TRIANGLES);
        //glColor3f(0, 1, 0);
        glVertex2f(-600, 300);
        glVertex2f(-400, 300);
        glVertex2f(-500, 400);
        glEnd();


        glBegin(GL_TRIANGLES);
        //glColor3f(0, 1, 0);
        glVertex2f(-400, 300);
        glVertex2f(-200, 300);
        glVertex2f(-300, 400);
        glEnd();

        glBegin(GL_TRIANGLES);
        //glColor3f(0, 1, 0);
        glVertex2f(-200, 300);
        glVertex2f(0, 300);
        glVertex2f(-100, 400);
        glEnd();

        glBegin(GL_TRIANGLES);
        //glColor3f(0, 1, 0);
        glVertex2f(0, 300);
        glVertex2f(200, 300);
        glVertex2f(100, 400);
        glEnd();


        glBegin(GL_TRIANGLES);
       // glColor3f(0, 1, 0);
        glVertex2f(200, 300);
        glVertex2f(400, 300);
        glVertex2f(300, 400);
        glEnd();

        glBegin(GL_TRIANGLES);
        //glColor3f(0, 1, 0);
        glVertex2f(400, 300);
        glVertex2f(600, 300);
        glVertex2f(500, 400);
        glEnd();

         glBegin(GL_TRIANGLES);
        //glColor3f(0, 1, 0);
        glVertex2f(600, 300);
        glVertex2f(800, 300);
        glVertex2f(700, 400);
        glEnd();

          glBegin(GL_TRIANGLES);
        //glColor3f(0, 1, 0);
        glVertex2f(800, 300);
        glVertex2f(1000, 300);
        glVertex2f(900, 400);
        glEnd();

        glBegin(GL_TRIANGLES);
        //glColor3f(0, 1, 0);
        glVertex2f(1000, 300);
        glVertex2f(1200, 300);
        glVertex2f(1100, 400);
        glEnd();


    glFlush();
}
