void River()
{
    glBegin(GL_QUADS);
    //glColor3ub(102, 224, 255);
    glColor3ub(204, 153, 0);
	glVertex2f(-1200, -750);
    glVertex2f(1200, -750);
    glVertex2f(1200, -350);
    glVertex2f(-1200, -350);
    glEnd();
}
