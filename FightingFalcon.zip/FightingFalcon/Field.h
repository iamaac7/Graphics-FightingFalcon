void Field()
{
    glBegin(GL_QUADS);
    //glColor3ub(153, 135, 0);
	glColor3ub(179, 138, 31);
    glVertex2f(-1200, -350);
    glVertex2f(1200, -350);
    glVertex2f(1200, 300);
    glVertex2f(-1200, 300);
    glEnd();
}
